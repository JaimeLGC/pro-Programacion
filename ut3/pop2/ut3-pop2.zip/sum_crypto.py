# ******************
# SUMA CRIPTOGRÁFICA
# ******************
from pathlib import Path


def run(crypto_path: Path) -> float:
    # TU CÓDIGO AQUÍ
    sum_cr = 'output'

    return sum_cr


if __name__ == '__main__':
    run('data/sum_crypto/data1.crypto')